<?php
require_once 'csv_manager.php';

// Initialize CsvManager for each section
$personalInfoManager = new CsvManager("personal_info.csv");
$educationManager = new CsvManager("education.csv");
$skillsManager = new CsvManager("skills.csv");
$projectsManager = new CsvManager("projects.csv");

// Handle CRUD requests
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action'];
    $section = $_POST['section'];
    $index = isset($_POST['index']) ? (int)$_POST['index'] : null;
    $data = isset($_POST['data']) ? $_POST['data'] : null;

    // Determine the correct manager
    $manager = null;
    switch ($section) {
        case "personal_info": $manager = $personalInfoManager; break;
        case "education": $manager = $educationManager; break;
        case "skills": $manager = $skillsManager; break;
        case "projects": $manager = $projectsManager; break;
    }

    if ($manager) {
        if ($action === "add") {
            $manager->addRow($data);
        } elseif ($action === "update" && $index !== null) {
            $manager->updateRow($index, $data);
        } elseif ($action === "delete" && $index !== null) {
            $manager->deleteRow($index);
        }
    }

    // Redirect to avoid form resubmission
    header("Location: index.php");
    exit;
}

// Fetch all data for display
$personalInfo = $personalInfoManager->readAll();
$education = $educationManager->readAll();
$skills = $skillsManager->readAll();
$projects = $projectsManager->readAll();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD Utility for CV</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-4">
        <h1>CV Management System</h1>

        <!-- Personal Information Section -->
        <section class="mt-4">
            <h2>Personal Information</h2>
            <ul class="list-group mb-3">
                <?php foreach ($personalInfo as $index => $info): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= implode(", ", $info); ?>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="section" value="personal_info">
                            <input type="hidden" name="index" value="<?= $index; ?>">
                            <button class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
            <form method="POST" class="mb-3">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="section" value="personal_info">
                <input type="text" name="data[]" placeholder="Name" class="form-control mb-2" required>
                <input type="email" name="data[]" placeholder="Email" class="form-control mb-2" required>
                <input type="text" name="data[]" placeholder="Phone" class="form-control mb-2" required>
                <input type="text" name="data[]" placeholder="Location" class="form-control mb-2" required>
                <button class="btn btn-primary">Add Personal Info</button>
            </form>
        </section>

        <!-- Education Section -->
        <section class="mt-4">
            <h2>Education</h2>
            <ul class="list-group mb-3">
                <?php foreach ($education as $index => $edu): ?>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        <?= implode(", ", $edu); ?>
                        <form method="POST" class="d-inline">
                            <input type="hidden" name="action" value="delete">
                            <input type="hidden" name="section" value="education">
                            <input type="hidden" name="index" value="<?= $index; ?>">
                            <button class="btn btn-danger btn-sm">Delete</button>
                        </form>
                    </li>
                <?php endforeach; ?>
            </ul>
            <form method="POST" class="mb-3">
                <input type="hidden" name="action" value="add">
                <input type="hidden" name="section" value="education">
                <input type="text" name="data[]" placeholder="Degree" class="form-control mb-2" required>
                <input type="text" name="data[]" placeholder="Institution" class="form-control mb-2" required>
                <input type="text" name="data[]" placeholder="Year" class="form-control mb-2" required>
                <input type="text" name="data[]" placeholder="Grade" class="form-control mb-2" required>
                <button class="btn btn-primary">Add Education</button>
            </form>
        </section>

        <!-- Add similar sections for Skills and Projects -->
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
