<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dynamic CV - Vatsal Savaliya</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f8f9fa;
            color: #343a40;
        }
        .navbar {
            background-color: #007bff;
        }
        .navbar a {
            color: white !important;
        }
        .hero {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 50px 20px;
            border-radius: 8px;
            margin-bottom: 20px;
        }
        .hero h1 {
            font-size: 3rem;
            font-weight: 700;
        }
        .hero p {
            font-size: 1.2rem;
            margin-top: 10px;
        }
        section {
            background-color: #ffffff;
            border-radius: 8px;
            box-shadow: 0px 4px 6px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-bottom: 20px;
        }
        section h2 {
            font-size: 1.8rem;
            color: #495057;
            margin-bottom: 1rem;
        }
        .list-group-item {
            background-color: #f8f9fa;
            border: none;
            padding: 10px 15px;
            border-left: 4px solid #007bff;
        }
        .footer {
            background-color: #007bff;
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: 20px;
            border-radius: 8px;
        }
        .footer a {
            color: white;
            text-decoration: underline;
        }
        @media (max-width: 768px) {
            .hero h1 {
                font-size: 2.5rem;
            }
            .hero p {
                font-size: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg">
        <div class="container">
            <a class="navbar-brand" href="#">Vatsal Savaliya</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNav">
                <ul class="navbar-nav ms-auto">
                    <li class="nav-item"><a class="nav-link" href="#personal-info">Personal Info</a></li>
                    <li class="nav-item"><a class="nav-link" href="#education">Education</a></li>
                    <li class="nav-item"><a class="nav-link" href="#skills">Skills</a></li>
                    <li class="nav-item"><a class="nav-link" href="#projects">Projects</a></li>
                </ul>
            </div>
        </div>
    </nav>

    <!-- Hero Section -->
    <div class="hero">
        <h1>Vatsal Savaliya</h1>
        <p>Aspiring IT Professional | Web Developer | Problem Solver</p>
    </div>

    <div class="container">
        <!-- Personal Information -->
        <section id="personal-info" class="my-4">
            <h2>Personal Information</h2>
            <?php
            include 'db_connection.php'; // Include database connection
            // Fetch personal information from the database
            $sql = "SELECT name, email, phone, location FROM personal_info LIMIT 1";
            $result = $conn->query($sql);
            if ($result->num_rows > 0) {
                $personal_info = $result->fetch_assoc();
                echo "<p><strong><i class='fas fa-user'></i> Name:</strong> " . $personal_info['name'] . "</p>";
                echo "<p><strong><i class='fas fa-envelope'></i> Email:</strong> " . $personal_info['email'] . "</p>";
                echo "<p><strong><i class='fas fa-phone'></i> Phone:</strong> " . $personal_info['phone'] . "</p>";
                echo "<p><strong><i class='fas fa-map-marker-alt'></i> Location:</strong> " . $personal_info['location'] . "</p>";
            } else {
                echo "<p>No data found in the personal_info table.</p>";
            }
            ?>
        </section>

        <!-- Education -->
        <section id="education" class="my-4">
            <h2>Education</h2>
            <ul class="list-group">
                <?php
                // Fetch education details from the database
                $sql = "SELECT degree, institute, year, grade FROM education";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($data = $result->fetch_assoc()) {
                        echo "<li class='list-group-item'><strong>{$data['degree']}</strong> at {$data['institute']} ({$data['year']}), Grade: {$data['grade']}</li>";
                    }
                } else {
                    echo "<p>No education data found.</p>";
                }
                ?>
            </ul>
        </section>

        <!-- Skills -->
        <section id="skills" class="my-4">
            <h2>Skills</h2>
            <ul class="list-group">
                <?php
                // Fetch skills from the database
                $sql = "SELECT skill FROM skills";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($data = $result->fetch_assoc()) {
                        echo "<li class='list-group-item'><i class='fas fa-check-circle'></i> {$data['skill']}</li>";
                    }
                } else {
                    echo "<p>No skills found.</p>";
                }
                ?>
            </ul>
        </section>

        <!-- Projects -->
        <section id="projects" class="my-4">
            <h2>Projects</h2>
            <ul class="list-group">
                <?php
                // Fetch projects from the database
                $sql = "SELECT title, year FROM projects";
                $result = $conn->query($sql);
                if ($result->num_rows > 0) {
                    while ($data = $result->fetch_assoc()) {
                        echo "<li class='list-group-item'><strong><i class='fas fa-folder'></i> {$data['title']}</strong> ({$data['year']})</li>";
                    }
                } else {
                    echo "<p>No projects found.</p>";
                }
                ?>
            </ul>
        </section>
    </div>

    <!-- Footer -->
    <footer class="footer">
        <p>&copy; 2024 Vatsal Savaliya. Built with <i class="fas fa-heart"></i>.</p>
        <p>Follow me on <a href="#">LinkedIn</a> | <a href="#">GitHub</a></p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
