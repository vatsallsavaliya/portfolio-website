<?php
include 'db_connection.php'; // Include MySQL connection

// Handle CRUD operations (Add, Update, Delete)
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $action = $_POST['action']; // Action type (add, update, delete)
    $section = $_POST['section']; // Section to apply the action (personal_info, education, skills, projects)
    $index = isset($_POST['index']) ? (int)$_POST['index'] : null; // Index for update/delete
    $data = isset($_POST['data']) ? $_POST['data'] : null; // Data for insert/update

    // Handle Add operation
    if ($action === 'add') {
        if ($section === 'personal_info') {
            $sql = "INSERT INTO personal_info (name, email, phone, location) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $data[0], $data[1], $data[2], $data[3]);
            $stmt->execute();
        } elseif ($section === 'education') {
            $sql = "INSERT INTO education (degree, institute, year, grade) VALUES (?, ?, ?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssss", $data[0], $data[1], $data[2], $data[3]);
            $stmt->execute();
        } elseif ($section === 'skills') {
            $sql = "INSERT INTO skills (skill) VALUES (?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("s", $data[0]);
            $stmt->execute();
        } elseif ($section === 'projects') {
            $sql = "INSERT INTO projects (title, year) VALUES (?, ?)";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $data[0], $data[1]);
            $stmt->execute();
        }
    }

    // Handle Update operation
    if ($action === 'update' && $index !== null) {
        if ($section === 'personal_info') {
            $sql = "UPDATE personal_info SET name = ?, email = ?, phone = ?, location = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssi", $data[0], $data[1], $data[2], $data[3], $index);
            $stmt->execute();
        } elseif ($section === 'education') {
            $sql = "UPDATE education SET degree = ?, institute = ?, year = ?, grade = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("ssssi", $data[0], $data[1], $data[2], $data[3], $index);
            $stmt->execute();
        } elseif ($section === 'skills') {
            $sql = "UPDATE skills SET skill = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("si", $data[0], $index);
            $stmt->execute();
        } elseif ($section === 'projects') {
            $sql = "UPDATE projects SET title = ?, year = ? WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("sii", $data[0], $data[1], $index);
            $stmt->execute();
        }
    }

    // Handle Delete operation
    if ($action === 'delete' && $index !== null) {
        if ($section === 'personal_info') {
            $sql = "DELETE FROM personal_info WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $index);
            $stmt->execute();
        } elseif ($section === 'education') {
            $sql = "DELETE FROM education WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $index);
            $stmt->execute();
        } elseif ($section === 'skills') {
            $sql = "DELETE FROM skills WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $index);
            $stmt->execute();
        } elseif ($section === 'projects') {
            $sql = "DELETE FROM projects WHERE id = ?";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param("i", $index);
            $stmt->execute();
        }
    }

    // Redirect to avoid resubmission of form
    header("Location: index.php");
    exit;
}
?>
